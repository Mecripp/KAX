KAX R2.3 for KSP 0.25.0

Extract KAX and Firespitter folders into your Gamedata folder.  If you already have Firespitter, use the lastest version of the Firespitter.dll.

See the official thread for details: http://forum.kerbalspaceprogram.com/threads/76668

===========================CREDITS===========================


KAX wouldn't be possible without Firespitter!
Big thanks to Snjo and the Firespitter mod & plugin: http://forum.kerbalspaceprogram.com/threads/24551




===========================LICENSE===========================

KAX models, textures, and sounds are created by Keptin, who retains all copyrights.
Snjo retains all rights for the Firespitter plugin, see Firespitter license for details.

You may:
Modify KAX in anyway for your personal use
Distribute video, screenshots or other media portraying unmodified or modified versions of KAX
All other rights are reserved

Specifically, you may not:
Distribute modified or unmodified versions of KAX, in part or whole, without permission
Use models, textures, sounds or other assets from KAX without permission
Use KAX for any commercial purpose