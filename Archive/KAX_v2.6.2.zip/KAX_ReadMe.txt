KAX v2.6.2 for KSP 1.1.2

Known Issues: Part sound only comes out of right speakers; audio config not yet transitioned to new module format

Extract the KAX folder, Firespitter folder, and ModuleManager.dll into your Gamedata folder.  
Be sure to properly extract the Firespitter/Resources folder or you will have FScoolant errors.  
If you already have Firespitter and/or Module Manager, use the latest versions of their .dll plugins.

See the official thread for details: http://forum.kerbalspaceprogram.com/threads/76668

===========================CREDITS===========================


KAX wouldn't be possible without Firespitter!
Big thanks to Snjo, Roverdude, and the Firespitter team: http://forum.kerbalspaceprogram.com/threads/24551



===========================LICENSE===========================

KAX models, textures, and sounds are created by Keptin, who retains all copyrights.
Snjo retains all rights for the Firespitter plugin, see Firespitter license for details.

You may:
Modify KAX in anyway for your personal use
Use KAX models, textures, and assets to create derivative works
Distribute sufficiently modified versions of KAX parts or newly created derivative parts if you credit the original work
Distribute video, screenshots or other media portraying unmodified or modified versions of KAX
All other rights are reserved

Specifically, you may not:
Distribute unmodified versions of KAX, in part or whole, without permission
Use KAX for any commercial purpose