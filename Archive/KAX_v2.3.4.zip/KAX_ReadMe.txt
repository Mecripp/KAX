KAX v2.3.4 for KSP 0.90

Extract KAX and Firespitter folders and ModuleManager.dll into your Gamedata folder.  
Be sure to properly extract the Firespitter/Resources folder or you will have FScoolant errors.  
If you already have Firespitter and/or Module Manager, use the latest versions of their .dll plugins.

See the official thread for details: http://forum.kerbalspaceprogram.com/threads/76668

===========================CREDITS===========================


KAX wouldn't be possible without Firespitter!
Big thanks to Snjo and the Firespitter mod & plugin: http://forum.kerbalspaceprogram.com/threads/24551




===========================LICENSE===========================

KAX models, textures, and sounds are created by Keptin, who retains all copyrights.
Snjo retains all rights for the Firespitter plugin, see Firespitter license for details.

You may:
Modify KAX in anyway for your personal use
Distribute video, screenshots or other media portraying unmodified or modified versions of KAX
All other rights are reserved

Specifically, you may not:
Distribute modified or unmodified versions of KAX, in part or whole, without permission
Use models, textures, sounds or other assets from KAX without permission
Use KAX for any commercial purpose